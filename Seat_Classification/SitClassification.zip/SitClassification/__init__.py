# -*- coding: utf-8 -*-
"""
Created on Thu Oct 17 22:26:22 2024

@author: 叶小明
"""
# SitClassification/__init__.py

from .SitClassificationInterfaces import SitPostureClassify
