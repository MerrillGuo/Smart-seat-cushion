# -*- coding: utf-8 -*-
"""
Created on Thu Oct 17 22:26:22 2024

@author: 叶小明
"""
# setup.py
from setuptools import setup, find_packages
 
setup(
    name='SitClassification',
    version='0.1',
    packages=find_packages(),
    description='A Python package for sitting posture classifcation',
    author='Haojiangye',
    author_email='yhjiang0114@163.com',
)
